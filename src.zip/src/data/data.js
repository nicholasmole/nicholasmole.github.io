
export const headerTop = {
	headerTop:
		[
			{
				id: 1,
				src: 'fancy_computer_image_.jpeg',
				alt: 'Fancy Computer Image',
				title: 'Nick Mole',
				subtitle: 'Web Developer'
			}
		]
};

export const projectStuff = {
	projectStuff:
	[
		{
			href: 'https://www.fake.com/',
			img: '../fake.png',
			title: 'DATA'
		},
		{
			href: 'https://www.fake2.com/',
			img: '../fake2.png',
			title: 'DATA2'
		}
	]
};
