const renderEditorText = props => {
	return <div dangerouslySetInnerHTML={{__html: props}}/>;
};
export default renderEditorText;
